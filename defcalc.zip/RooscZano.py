#Roosc Zano

import mathe

n1 = int(input("Input 1st Number: "))
n2 = int(input("Input 2nd Number: "))
method = input("Enter the method that will be used (+ - / *): ")

if method == '+':
    print(mathe.addition(n1, n2))
elif method == '-':
    print(mathe.subtraction(n1, n2))
elif method == '*':
    print(mathe.multiplication(n1, n2))
elif method == '/':
    print(mathe.division(n1, n2))
else:
    print("INVALID, PLEASE SELECT THE RIGHT METHOD.")