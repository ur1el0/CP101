from tkinter import *

def button_press(num):
    pass

def equals():
    pass

def clear():
    pass

window = Tk()
window.title("Calculator")
window.geometry("500x500")

window.mainloop()
